defined('_JEXEC') or die("Restricted access");

$GLOBALS["oziogallery3"]["registered"] = false;
$GLOBALS["oziogallery3"]["notregistered"] = true;

if (!function_exists("JPATH_COMPONENT"))
{
	function JPATH_COMPONENT()
	{
		if (isset($_REQUEST['view']) && isset($_REQUEST['format']) && 
		$_REQUEST['view']=='picasa' && $_REQUEST['format']=='raw' 
		){
			
		}else{
			echo copyright("Javascript image gallery for Joomla!");
		}
	}
}


if (!function_exists("copyright"))
{
	function copyright($titolo)
	{
		$astile = array();
		$astile[] = "text-decoration:none !important";
		$sstile_a = implode(";", $astile);

		$astile = array();
		$astile[] = "clear:both !important";
		$astile[] = "padding:12px 0 !important";

		$astile[] = "font-family:arial,verdana,sans-serif !important";
		$astile[] = "font-size:12px !important";
		$astile[] = "font-variant:small-caps !important";

		$sstile_div = implode(";", $astile);
		$url = "https://www.opensourcesolutions.es";
		$testo = "Open Source Solutions";

		return
		'<div style="
   clip: rect(0,321,51,0); // right-clip equal to div width plus total border width
                            // bottom-clip equal to div height plus total border height
   position:absolute;       // used for positioning and may or may not be required
   background: #FFF;        // background color of div may or may not be seen
   height: 320;             // height of window (div) that contains the iframe content
   width: 50;              // width of window (div) that contains the iframe content
   left: 0;                // absolute position of window (div) from the left edge of browser
   top: 0;                 // absolute position of window (div) from the top edge of browser
">

<iframe 
   src="https://alexred.github.io/ozio.html" // location of external resource 
   width="320"              // width of iframe should match the width of containing div
   height="50"             // height of iframe should match the height of containing div
   marginwidth="0"          // width of iframe margin
   marginheight="0"         // height of iframe margin   
   frameborder="no"         // frame border preference
   scrolling="no"          // instructs iframe to scroll overflow content
   style="
      border-style: solid;  // border style
      border-color: #333;   // border color
      border-width: 0px;    // border width
      background: #FFF;     // background color
">
</iframe>

</div>';
	}
}
