defined('_JEXEC') or die("Restricted access");

$GLOBALS["oziogallery3"]["registered"] = false;
$GLOBALS["oziogallery3"]["notregistered"] = true;

if (!function_exists("JPATH_COMPONENT"))
{
	function JPATH_COMPONENT()
	{
		if (isset($_REQUEST['view']) && isset($_REQUEST['format']) && 
		$_REQUEST['view']=='picasa' && $_REQUEST['format']=='raw' 
		){
			
		}else{
			echo copyright("Javascript image gallery for Joomla!");
		}
	}
}


if (!function_exists("copyright"))
{
	function copyright($titolo)
	{
		$astile = array();
		$astile[] = "text-decoration:none !important";
		$sstile_a = implode(";", $astile);

		$astile = array();
		$astile[] = "clear:both !important";
		$astile[] = "padding:12px 0 !important";

		$astile[] = "font-family:arial,verdana,sans-serif !important";
		$astile[] = "font-size:12px !important";
		$astile[] = "font-variant:small-caps !important";

		$sstile_div = implode(";", $astile);
		$url = "https://www.opensourcesolutions.es";
		$testo = "Open Source Solutions";

		return
		'<div style="' . $sstile_div . '">' .
		'Ozio Gallery made with ❤ by <a style="' . $sstile_a . '" ' .
		'href="' . $url . '" target="_blank" rel="noopener noreferrer">' .
		$testo .
		'</a></div>';
	}
}
