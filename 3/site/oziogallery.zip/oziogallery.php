defined('_JEXEC') or die("Restricted access");

$GLOBALS["oziogallery3"]["registered"] = false;

if (!function_exists("JPATH_COMPONENT"))
{
	function JPATH_COMPONENT()
	{
		echo copyright("Javascript image gallery for Joomla!");
	}
}


if (!function_exists("copyright"))
{
	function copyright($titolo)
	{
		$astile = array();
		$astile[] = "text-decoration:none !important";
		$sstile_a = implode(";", $astile);

		$astile = array();
		$astile[] = "clear:both !important";
		$astile[] = "padding:10px 0 !important";

		$astile[] = "font-family:arial,verdana,sans-serif !important";
		$astile[] = "font-size:10px !important";
		$astile[] = "font-variant:small-caps !important";

		$sstile_div = implode(";", $astile);
		$url = "http://extensions.joomla.org/extensions/photos-a-images/galleries/photo-flash-gallery/4883";
		$testo = "ozio gallery";

		return
		'<div style="' . $sstile_div . '">' .
		'powered by <a style="' . $sstile_a . '" ' .
		'href="' . $url . '" title="' . $titolo . '" target="_blank">' .
		$testo .
		'</a></div>';
	}
}
