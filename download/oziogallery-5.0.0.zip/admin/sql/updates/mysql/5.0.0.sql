 
UPDATE `#__ozio_setup` SET `status`='pending';

