DROP TABLE IF EXISTS `#__ozio_setup`;
